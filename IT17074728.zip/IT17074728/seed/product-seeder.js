var Product = require('../models/product');

var mongoose = require('mongoose');

mongoose.connect('localhost:27017/shop');

//Ticket details storing in db
var products = [
    new Product({
        imagePath: 'https://target.scene7.com/is/image/Target/GUEST_794781eb-b101-4e66-bfbe-e85c3baf20bc',
        title: 'PURSE',
        description: 'PURSE',
        price: 700
    }),
    new Product({
        imagePath: 'https://target.scene7.com/is/image/Target/GUEST_794781eb-b101-4e66-bfbe-e85c3baf20bc',
        title: 'PURSE',
        description: 'PURSE',
        price: 'Rs.850'
    }),
    new Product({
        imagePath: 'https://target.scene7.com/is/image/Target/GUEST_794781eb-b101-4e66-bfbe-e85c3baf20bc',
        title: 'PURSE',
        description: 'PURSE',
        price: 800
    }),
    new Product({
        imagePath: 'https://target.scene7.com/is/image/Target/GUEST_794781eb-b101-4e66-bfbe-e85c3baf20bc',
        title: 'PURSE',
        description: 'purse',
        price: 950
    }),
    new Product({
        imagePath: 'https://target.scene7.com/is/image/Target/GUEST_794781eb-b101-4e66-bfbe-e85c3baf20bc',
        title: 'PURSE',
        description: 'purse',
        price: 650
    }),
    new Product({
        imagePath: 'https://target.scene7.com/is/image/Target/GUEST_794781eb-b101-4e66-bfbe-e85c3baf20bc',
        title: 'Colombo-Trinco',
        description: 'purse',
        price: 850
    }),
    new Product({
        imagePath: 'https://target.scene7.com/is/image/Target/GUEST_794781eb-b101-4e66-bfbe-e85c3baf20bc',
        title: 'PURSE',
        description: 'purse',
        price: 650
    }),
    new Product({
        imagePath: 'https://target.scene7.com/is/image/Target/GUEST_794781eb-b101-4e66-bfbe-e85c3baf20bc,
        title: 'PURSE',
        description: 'purse',
        price: 1500
    })
];

var done = 0;
for (var i = 0; i < products.length; i++) {
    products[i].save(function(err, result) {
        done++;
        if (done === products.length) {
            exit();
        }
    });
}

function exit() {
    mongoose.disconnect(); //disconnecting db
}