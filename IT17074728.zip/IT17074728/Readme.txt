PAF- Online
IT17074728 - C.J.T. Ranatunga

How to deploy the project.

As the Handlebars, Javascript and Jquery has been used,
The client and the Server both are included in the project
So it can be deployed easily.
mobgodb should be installed and mongod app shud be running in background

open this folder as a project in webstorm
in terminal   "run npm install"
then change directory to seed and run "node product-seeder.js"
then in new terminal run "npm start"
open chrome and goto localhost:3000
Now you can use the app.


Thanks